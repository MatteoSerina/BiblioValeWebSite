<?php
  /*
  * File contentente i parametri di configurazione
  */
  $session_name = "login";
?>