/**
 * @author Matteo
 */
$(document).ready(function() 
    { 
        $("#myTable").tablesorter(); 
    } 
); 